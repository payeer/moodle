<?php

defined('MOODLE_INTERNAL') or die();

$plugin->version = 2014031300;
$plugin->requires = 2010112400;
$plugin->component = 'enrol_payeer';
$plugin->cron      = 600;
$plugin->release = '1.1.0';

