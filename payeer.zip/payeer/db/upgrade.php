<?php

function xmldb_enrol_payeer_upgrade($oldversion=0) 
{
    return true;
}