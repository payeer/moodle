Payeer Enrolment Plugin
====================

Simple enrolment plugin for Moodle 2.x using the Payeer payment gateway.


